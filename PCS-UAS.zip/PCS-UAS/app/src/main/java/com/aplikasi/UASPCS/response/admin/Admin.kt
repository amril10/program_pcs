package com.aplikasi.UASPCS.response.admin

data class Admin(
    val email: String,
    val nama: String,
    val password: String
)